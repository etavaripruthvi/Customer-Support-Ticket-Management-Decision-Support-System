from datetime import datetime, timezone

try:
    from .extensions import db
except ImportError:  # pragma: no cover - supports direct script execution
    from extensions import db


class Ticket(db.Model):
    __tablename__ = 'tickets'

    id = db.Column(db.String(50), primary_key=True)
    email = db.Column(db.String(255), nullable=False)
    subject = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    attachment_name = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='Open')
    priority = db.Column(db.String(20), nullable=False, default='Medium')
    # Research metadata
    complexity_score = db.Column(db.Float, default=0.0)
    sentiment = db.Column(db.String(20), default='Neutral')
    urgency_factors = db.Column(db.Text, nullable=True)
    assigned_researcher = db.Column(db.String(255), nullable=True)
    resolution_confidence = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
    resolved_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'subject': self.subject,
            'category': self.category,
            'description': self.description,
            'attachment_name': self.attachment_name,
            'status': self.status,
            'priority': self.priority,
            'complexity_score': self.complexity_score,
            'sentiment': self.sentiment,
            'resolution_confidence': self.resolution_confidence,
            'assigned_researcher': self.assigned_researcher,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
        }


class Complaint(db.Model):
    __tablename__ = 'complaints'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    complaint_id = db.Column(db.String(50), unique=True, nullable=False)
    customer_name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    product = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(30), nullable=False, default='Open')
    priority = db.Column(db.String(20), nullable=False, default='Medium')
    employee_name = db.Column(db.String(255), nullable=True)
    solution_summary = db.Column(db.Text, nullable=True)
    # Academic research fields
    root_cause_category = db.Column(db.String(100), nullable=True)
    impact_level = db.Column(db.String(20), default='Medium')
    recurrence_count = db.Column(db.Integer, default=0)
    research_notes = db.Column(db.Text, nullable=True)
    resolution_time_hours = db.Column(db.Float, nullable=True)
    customer_satisfaction_score = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
    closed_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        resolution_summary = self.solution_summary or 'Resolution pending review.'
        return {
            'id': self.complaint_id,
            'customer_name': self.customer_name,
            'email': self.email,
            'product': self.product,
            'category': self.category,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'employee_name': self.employee_name,
            'solution_summary': resolution_summary,
            'resolution_summary': resolution_summary,
            'root_cause_category': self.root_cause_category,
            'impact_level': self.impact_level,
            'recurrence_count': self.recurrence_count,
            'resolution_time_hours': self.resolution_time_hours,
            'customer_satisfaction_score': self.customer_satisfaction_score,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'closed_at': self.closed_at.isoformat() if self.closed_at else None,
        }
