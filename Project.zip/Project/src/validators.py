import re

VALID_STATUSES = {'Open', 'In Progress', 'Resolved', 'Closed'}
VALID_PRIORITIES = {'Low', 'Medium', 'High', 'Urgent'}
ALLOWED_ATTACHMENT_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf', 'docx'}


def validate_ticket_submission(data: dict) -> dict:
    """Validate ticket creation payloads."""
    errors: list[str] = []

    email = str(data.get('email', '') or '').strip()
    email_regex = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    if not email:
        errors.append('Email is required.')
    elif not re.fullmatch(email_regex, email):
        errors.append('Invalid email address format.')

    for field in ['subject', 'category', 'description']:
        value = data.get(field)
        if value is None or not str(value).strip():
            errors.append(f"Field '{field}' cannot be empty.")

    filename = str(data.get('attachment_name', '') or '').strip()
    if filename:
        if '.' not in filename:
            errors.append('Attachment filename must include a valid file extension.')
        else:
            ext = filename.rsplit('.', 1)[-1].lower()
            if ext not in ALLOWED_ATTACHMENT_EXTENSIONS:
                allowed = ', '.join(sorted(ALLOWED_ATTACHMENT_EXTENSIONS))
                errors.append(f"Invalid file type '.{ext}'. Allowed types: {allowed}")

    status = str(data.get('status', '') or '').strip()
    if status and status not in VALID_STATUSES:
        errors.append(f"Invalid status '{status}'. Allowed values: {', '.join(sorted(VALID_STATUSES))}.")

    priority = str(data.get('priority', '') or '').strip()
    if priority and priority not in VALID_PRIORITIES:
        errors.append(f"Invalid priority '{priority}'. Allowed values: {', '.join(sorted(VALID_PRIORITIES))}.")

    return {'is_valid': not errors, 'errors': errors}


def validate_ticket_update(data: dict) -> dict:
    """Validate partial status/priority updates."""
    errors: list[str] = []

    if 'status' in data and data['status'] not in VALID_STATUSES:
        errors.append(f"Invalid status '{data['status']}'. Allowed values: {', '.join(sorted(VALID_STATUSES))}.")

    if 'priority' in data and data['priority'] not in VALID_PRIORITIES:
        errors.append(f"Invalid priority '{data['priority']}'. Allowed values: {', '.join(sorted(VALID_PRIORITIES))}.")

    return {'is_valid': not errors, 'errors': errors}
