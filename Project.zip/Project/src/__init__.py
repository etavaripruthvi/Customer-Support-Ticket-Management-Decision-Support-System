"""Customer Support Ticket Management System package."""

from .app import app
