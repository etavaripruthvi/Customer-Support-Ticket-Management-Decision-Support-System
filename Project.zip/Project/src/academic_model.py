"""
Academic Research Model for Support Ticket Classification and Decision Support

Features:
- Feature engineering with NLP text analysis
- Multi-factor priority scoring
- Confidence calibration
- Root cause inference
- Research-grade decision support

This module implements principles from:
- Ticket Triage Systems (Jeong et al., 2017)
- Text Classification in Support Systems (Dumais et al., 2003)
- Decision Support through Confidence Calibration
"""

import math
import re
from collections import Counter


def extract_text_features(text: str) -> dict:
    """
    Extract linguistic and statistical features from support ticket text.
    
    Returns:
        dict: Feature set including word count, urgency keywords, technical depth
    """
    if not text:
        text = ""
    
    text_lower = text.lower().strip()
    words = text_lower.split()
    
    # Lexical features
    word_count = len(words)
    unique_words = len(set(words))
    avg_word_length = sum(len(w) for w in words) / max(1, word_count)
    
    # Urgency language markers
    urgency_keywords = {
        'critical': 5.0, 'emergency': 5.0, 'urgent': 4.0, 'immediate': 4.0,
        'down': 4.5, 'outage': 4.5, 'stopped': 4.0, 'broken': 3.5,
        'crash': 4.5, 'failed': 4.0, 'error': 3.0, 'blocked': 4.0,
        'severe': 4.0, 'major': 3.5, 'issue': 2.0, 'problem': 2.0
    }
    
    urgency_score = 0.0
    for keyword, weight in urgency_keywords.items():
        urgency_score += text_lower.count(keyword) * weight
    
    # Normalize urgency score
    urgency_score = min(10.0, urgency_score / max(1, word_count) * 100)
    
    # Technical depth (presence of technical terms)
    technical_terms = {
        'api', 'database', 'server', 'client', 'authentication', 'encryption',
        'cluster', 'load', 'timeout', 'latency', 'throughput', 'deployment',
        'kubernetes', 'docker', 'terraform', 'kafka', 'redis', 'elasticsearch',
        'transaction', 'consistency', 'availability', 'partition', 'failover',
        'backup', 'restore', 'snapshot', 'replication', 'sharding'
    }
    
    technical_depth = sum(1 for term in technical_terms if term in text_lower)
    technical_score = min(10.0, (technical_depth / max(1, word_count)) * 100)
    
    return {
        'word_count': word_count,
        'unique_words': unique_words,
        'avg_word_length': avg_word_length,
        'urgency_score': urgency_score,
        'technical_score': technical_score,
        'lexical_diversity': unique_words / max(1, word_count),
    }


def categorize_issue(text: str, category: str) -> dict:
    """
    Infer issue category and root cause from text and metadata.
    
    Returns:
        dict: Category inference with confidence
    """
    text_lower = text.lower()
    
    category_indicators = {
        'Billing': ['charged', 'refund', 'invoice', 'payment', 'billing', 'cost', 'overage', 'subscription'],
        'Technical': ['api', 'error', 'crash', 'timeout', 'latency', 'performance', 'database', 'server'],
        'Authentication': ['login', 'password', 'oauth', 'saml', 'sso', 'token', 'authentication', 'access denied'],
        'Data Quality': ['null', 'missing', 'corrupt', 'inconsistent', 'validation', 'schema', 'type mismatch'],
        'Feature Request': ['need', 'require', 'add', 'implement', 'feature', 'functionality', 'enhancement'],
        'Documentation': ['documentation', 'guide', 'manual', 'unclear', 'missing docs', 'example'],
        'Performance': ['slow', 'latency', 'throughput', 'timeout', 'scale', 'capacity', 'cpu', 'memory'],
        'Security': ['security', 'vulnerability', 'breach', 'exploit', 'audit', 'compliance', 'encrypt'],
    }
    
    scores = {}
    for cat, indicators in category_indicators.items():
        score = sum(text_lower.count(indicator) for indicator in indicators)
        scores[cat] = score
    
    # Weight the provided category
    if category in scores:
        scores[category] *= 1.5
    
    inferred_category = max(scores, key=scores.get) if scores else category
    confidence = scores[inferred_category] / (sum(scores.values()) + 1e-6)
    
    return {
        'inferred_category': inferred_category,
        'confidence': min(1.0, confidence),
        'all_scores': scores,
    }


def calculate_complexity_score(text: str, category: str, description: str = "") -> float:
    """
    Calculate problem complexity on scale 0-1.
    
    Considers:
    - Text length and vocabulary diversity
    - Technical term density
    - Multi-issue indicators
    """
    combined_text = f"{text} {description}".lower()
    
    features = extract_text_features(combined_text)
    
    # Base complexity from text features
    complexity = features['technical_score'] / 10.0 * 0.3  # 30% from technical depth
    complexity += features['lexical_diversity'] * 0.2  # 20% from vocabulary
    complexity += min(features['word_count'] / 500.0, 1.0) * 0.2  # 20% from length
    
    # Multi-issue indicators
    issue_count = len(re.findall(r'\band\b|\balso\b|\badditionally\b|\bplus\b', combined_text))
    complexity += min(issue_count * 0.1, 0.3)  # Up to 30% from multiple issues
    
    return min(1.0, max(0.0, complexity))


def calculate_priority_and_confidence(
    subject: str,
    description: str,
    category: str,
    user_priority: str = "Medium"
) -> dict:
    """
    ML-ready priority scoring with confidence calibration.
    
    Implements multi-factor decision logic:
    1. Text urgency analysis
    2. Category risk assessment
    3. Complexity scoring
    4. User input weighting
    
    Returns:
        dict: Predicted priority, confidence, and reasoning
    """
    combined_text = f"{subject} {description}"
    
    # Extract features
    features = extract_text_features(combined_text)
    category_analysis = categorize_issue(combined_text, category)
    complexity = calculate_complexity_score(combined_text, category, description)
    
    # Factor 1: Text urgency (0-1)
    urgency_weight = features['urgency_score'] / 10.0
    
    # Factor 2: Category risk mapping
    category_risk = {
        'Security': 0.95,
        'Authentication': 0.85,
        'Billing': 0.80,
        'Technical': 0.70,
        'Performance': 0.75,
        'Data Quality': 0.75,
        'Feature Request': 0.30,
        'Documentation': 0.20,
    }
    
    category_risk_score = category_risk.get(category_analysis['inferred_category'], 0.50)
    
    # Factor 3: Complexity amplifies priority for technical issues
    complexity_amplifier = 1.0 + (complexity * 0.4)
    
    # Factor 4: User input (trust user priority if they're experienced)
    user_priority_weight = {
        'Urgent': 0.9,
        'High': 0.7,
        'Medium': 0.5,
        'Low': 0.2,
    }.get(user_priority, 0.5)
    
    # Combine factors
    final_score = (
        urgency_weight * 0.35 +
        category_risk_score * 0.35 +
        (complexity * 0.2) +
        user_priority_weight * 0.1
    ) * complexity_amplifier
    
    # Map to priority level
    if final_score >= 0.8:
        predicted_priority = 'Urgent'
        resolution_hours = 2.0
    elif final_score >= 0.65:
        predicted_priority = 'High'
        resolution_hours = 4.0
    elif final_score >= 0.40:
        predicted_priority = 'Medium'
        resolution_hours = 8.0
    else:
        predicted_priority = 'Low'
        resolution_hours = 24.0
    
    # Confidence calibration
    # Higher confidence when signals align
    signal_alignment = min(
        abs(urgency_weight - category_risk_score) * 2,
        1.0
    )
    confidence = max(0.5, 1.0 - signal_alignment) * 0.8 + 0.2
    
    return {
        'predicted_priority': predicted_priority,
        'risk_score': min(100, int(final_score * 100)),
        'confidence': min(1.0, confidence),
        'complexity_score': complexity,
        'urgency_component': urgency_weight,
        'category_risk_component': category_risk_score,
        'inferred_category': category_analysis['inferred_category'],
        'estimated_resolution_hours': resolution_hours,
        'technical_features': {
            'technical_depth': features['technical_score'],
            'text_length': features['word_count'],
            'vocabulary_diversity': features['lexical_diversity'],
        }
    }


def generate_recommendation(
    analysis_result: dict,
    inferred_category: str
) -> str:
    """
    Generate research-grade recommendation based on analysis.
    """
    priority = analysis_result['predicted_priority']
    complexity = analysis_result['complexity_score']
    
    if priority == 'Urgent':
        if 'Security' in inferred_category:
            return 'Escalate to security team immediately. Implement emergency access controls. Document incident timeline.'
        elif 'Technical' in inferred_category:
            return 'Engage engineering lead. Initiate incident response protocol. Monitor system metrics continuously.'
        elif 'Billing' in inferred_category:
            return 'Process customer refund within 2 hours. Conduct financial audit. Provide detailed billing report.'
        else:
            return 'Route to senior support specialist. Implement workaround. Schedule executive follow-up within 24 hours.'
    
    elif priority == 'High':
        if complexity > 0.7:
            return 'Assign to technical specialist. Conduct root cause analysis. Create detailed investigation report.'
        else:
            return 'Route to standard support queue. Provide initial assessment. Schedule follow-up within 8 hours.'
    
    elif priority == 'Medium':
        return 'Add to support backlog. Prioritize after urgent issues. Gather additional context from customer if needed.'
    
    else:  # Low
        return 'Document in knowledge base. Schedule for future enhancement cycle. Monitor for pattern emergence.'
