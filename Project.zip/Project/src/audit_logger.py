import logging
import os
from datetime import datetime, timezone

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log_dir = os.path.join(project_root, 'logs')
os.makedirs(log_dir, exist_ok=True)

logger = logging.getLogger('ticket_audit')
logger.setLevel(logging.INFO)
logger.propagate = False

if not logger.handlers:
    file_handler = logging.FileHandler(os.path.join(log_dir, 'ticket_audit.log'))
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)


def log_ticket_action(ticket_id: str, user_id: str, action: str, details: str = '') -> dict:
    """Write a structured audit record for ticket lifecycle actions."""
    timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    log_entry = {
        'timestamp': timestamp,
        'ticket_id': ticket_id,
        'performed_by': user_id,
        'action': action,
        'details': details,
    }
    logger.info(
        'TicketID: %s | User: %s | Action: %s | Details: %s',
        ticket_id,
        user_id,
        action,
        details,
    )
    return log_entry