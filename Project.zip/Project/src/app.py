import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, Response, jsonify, redirect, render_template_string, request, send_from_directory

try:
    from .audit_logger import log_ticket_action
    from .config import Config
    from .dashboard import generate_ticket_charts
    from .extensions import db
    from .models import Complaint, Ticket
    from .validators import validate_ticket_submission, validate_ticket_update
    from .academic_model import calculate_priority_and_confidence, generate_recommendation, calculate_complexity_score
    from .academic_data import get_academic_dataset
except ImportError:  # pragma: no cover - allows direct script execution
    from audit_logger import log_ticket_action
    from config import Config
    from dashboard import generate_ticket_charts
    from extensions import db
    from models import Complaint, Ticket
    from validators import validate_ticket_submission, validate_ticket_update
    from academic_model import calculate_priority_and_confidence, generate_recommendation, calculate_complexity_score
    from academic_data import get_academic_dataset

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)


@app.route('/')
def index():
    return redirect('/dashboard', code=302)


@app.route('/health')
def health_check():
    return jsonify({'status': 'ok', 'service': 'customer-support-system'}), 200


def seed_complaint_data():
    if Complaint.query.first():
        return

    academic_data = get_academic_dataset()
    
    for complaint_data in academic_data:
        db.session.add(Complaint(**complaint_data))
    db.session.commit()


def seed_synthetic_tickets():
    """Add synthetic demo tickets for dashboard visualization."""
    if Ticket.query.first():
        return
    
    from datetime import timedelta
    synthetic_tickets = [
        {'email': 'john.smith@example.com', 'subject': 'API Rate Limiting Issues', 'category': 'Technical', 'description': 'Experiencing 429 errors on bulk operations endpoint', 'status': 'Open', 'priority': 'High'},
        {'email': 'alice.jones@example.com', 'subject': 'Billing Invoice Missing', 'category': 'Billing', 'description': 'Invoice for March not received', 'status': 'In Progress', 'priority': 'Medium'},
        {'email': 'bob.wilson@example.com', 'subject': 'OAuth2 Token Refresh Failure', 'category': 'Technical', 'description': 'Refresh tokens expiring unexpectedly', 'status': 'Resolved', 'priority': 'Urgent'},
        {'email': 'carol.white@example.com', 'subject': 'Database Connection Timeout', 'category': 'Technical', 'description': 'Queries timing out during peak hours', 'status': 'In Progress', 'priority': 'High'},
        {'email': 'david.brown@example.com', 'subject': 'Subscription Downgrade Request', 'category': 'Billing', 'description': 'Need to downgrade to basic plan', 'status': 'Open', 'priority': 'Low'},
        {'email': 'emma.davis@example.com', 'subject': 'Mobile App Login Bug', 'category': 'Technical', 'description': 'Cannot login via iOS app', 'status': 'Resolved', 'priority': 'High'},
        {'email': 'frank.miller@example.com', 'subject': 'Feature Request: Export to CSV', 'category': 'General', 'description': 'Need bulk export functionality', 'status': 'Open', 'priority': 'Medium'},
        {'email': 'grace.taylor@example.com', 'subject': 'Documentation Outdated', 'category': 'General', 'description': 'API docs reference deprecated endpoints', 'status': 'Resolved', 'priority': 'Low'},
    ]
    
    for i, ticket_data in enumerate(synthetic_tickets):
        ticket = Ticket(
            id=f'TICK-{1000 + i}',
            email=ticket_data['email'],
            subject=ticket_data['subject'],
            category=ticket_data['category'],
            description=ticket_data['description'],
            status=ticket_data['status'],
            priority=ticket_data['priority'],
        )
        db.session.add(ticket)
    db.session.commit()


with app.app_context():
    db.create_all()
    seed_complaint_data()
    seed_synthetic_tickets()


def ensure_ticket_id():
    last_ticket = Ticket.query.order_by(Ticket.id.desc()).first()
    if last_ticket is None:
        return 'TICK-1001'
    last_number = int(last_ticket.id.split('-')[-1])
    return f'TICK-{last_number + 1}'


def analyze_ticket_with_model(data: dict) -> dict:
    """
    ML-ready ticket analysis using academic research model.
    
    Combines:
    - Natural language feature extraction
    - Multi-factor priority scoring
    - Confidence calibration
    - Root cause inference
    """
    subject = str(data.get('subject', '') or '')
    description = str(data.get('description', '') or '')
    category = str(data.get('category', 'General') or 'General').strip() or 'General'
    user_priority = str(data.get('priority', 'Medium') or 'Medium').strip() or 'Medium'

    # Calculate priority with ML model
    analysis = calculate_priority_and_confidence(
        subject=subject,
        description=description,
        category=category,
        user_priority=user_priority
    )
    
    # Generate research-grade recommendation
    recommendation = generate_recommendation(analysis, analysis['inferred_category'])
    
    # Calculate complexity score
    complexity = calculate_complexity_score(subject, category, description)
    
    return {
        'status': 'success',
        'prediction': {
            'predicted_priority': analysis['predicted_priority'],
            'risk_score': analysis['risk_score'],
            'recommended_action': recommendation,
            'confidence': round(analysis['confidence'], 3),
            'category': analysis['inferred_category'],
            'complexity_score': round(complexity, 2),
            'estimated_resolution_hours': analysis['estimated_resolution_hours'],
            'summary': f"Research analysis indicates {analysis['predicted_priority']} priority with {int(analysis['confidence']*100)}% confidence. Complexity score: {complexity:.2f}",
            'technical_depth': round(analysis['technical_features']['technical_depth'], 2),
            'text_analysis': {
                'urgency_component': round(analysis['urgency_component'], 2),
                'category_risk_component': round(analysis['category_risk_component'], 2),
                'text_length': analysis['technical_features']['text_length'],
                'vocabulary_diversity': round(analysis['technical_features']['vocabulary_diversity'], 2),
            }
        },
    }


@app.route('/api/model/analyze', methods=['POST'])
def analyze_model_ticket():
    data = request.get_json(silent=True) or {}
    if not data.get('subject') and not data.get('description'):
        return jsonify({'status': 'error', 'message': 'Subject or description is required for analysis.'}), 400

    result = analyze_ticket_with_model(data)
    return jsonify(result), 200


@app.route('/api/tickets', methods=['POST'])
def create_ticket():
    data = request.get_json(silent=True) or {}
    validation_result = validate_ticket_submission(data)
    if not validation_result['is_valid']:
        return jsonify({'status': 'error', 'errors': validation_result['errors']}), 400

    ticket = Ticket(
        id=ensure_ticket_id(),
        email=data['email'].strip(),
        subject=data['subject'].strip(),
        category=data['category'].strip(),
        description=data['description'].strip(),
        attachment_name=data.get('attachment_name', '').strip() or None,
        status=data.get('status', 'Open'),
        priority=data.get('priority', 'Medium'),
    )
    db.session.add(ticket)
    db.session.commit()

    log_ticket_action(
        ticket_id=ticket.id,
        user_id=data.get('user_id', 'SYSTEM_CUSTOMER'),
        action='TICKET_CREATED',
        details=f"Subject: {ticket.subject}",
    )

    return jsonify({'status': 'success', 'ticket': ticket.to_dict()}), 201


@app.route('/api/complaints', methods=['GET'])
def list_complaints():
    seed_complaint_data()
    complaints = [complaint.to_dict() for complaint in Complaint.query.order_by(Complaint.created_at.desc()).all()]
    return jsonify({'status': 'success', 'complaints': complaints, 'count': len(complaints)}), 200


@app.route('/api/tickets', methods=['GET'])
def list_tickets():
    status_filter = request.args.get('status')
    category_filter = request.args.get('category')

    query = Ticket.query
    if status_filter:
        query = query.filter(Ticket.status == status_filter)
    if category_filter:
        query = query.filter(Ticket.category == category_filter)

    tickets = [ticket.to_dict() for ticket in query.order_by(Ticket.created_at.desc()).all()]
    return jsonify({'status': 'success', 'tickets': tickets, 'count': len(tickets)}), 200


@app.route('/api/tickets/<ticket_id>', methods=['GET'])
def get_ticket(ticket_id):
    ticket = db.session.get(Ticket, ticket_id)
    if ticket is None:
        return jsonify({'status': 'error', 'message': 'Ticket not found'}), 404

    return jsonify({'status': 'success', 'ticket': ticket.to_dict()}), 200


@app.route('/api/tickets/<ticket_id>', methods=['PATCH'])
def update_ticket(ticket_id):
    ticket = db.session.get(Ticket, ticket_id)
    if ticket is None:
        return jsonify({'status': 'error', 'message': 'Ticket not found'}), 404

    data = request.get_json(silent=True) or {}
    validation_result = validate_ticket_update(data)
    if not validation_result['is_valid']:
        return jsonify({'status': 'error', 'errors': validation_result['errors']}), 400

    if 'status' in data:
        old_status = ticket.status
        ticket.status = data['status']
        log_ticket_action(
            ticket_id=ticket.id,
            user_id=data.get('user_id', 'UNKNOWN_USER'),
            action='STATUS_UPDATED',
            details=f"Changed status from '{old_status}' to '{ticket.status}'",
        )

    if 'priority' in data:
        old_priority = ticket.priority
        ticket.priority = data['priority']
        log_ticket_action(
            ticket_id=ticket.id,
            user_id=data.get('user_id', 'UNKNOWN_USER'),
            action='PRIORITY_UPDATED',
            details=f"Changed priority from '{old_priority}' to '{ticket.priority}'",
        )

    db.session.commit()
    return jsonify({'status': 'success', 'ticket': ticket.to_dict()}), 200


@app.route('/api/tickets/<ticket_id>', methods=['DELETE'])
def delete_ticket(ticket_id):
    ticket = db.session.get(Ticket, ticket_id)
    if ticket is None:
        return jsonify({'status': 'error', 'message': 'Ticket not found'}), 404

    user_id = (request.get_json(silent=True) or {}).get('user_id', 'UNKNOWN_USER')
    log_ticket_action(
        ticket_id=ticket.id,
        user_id=user_id,
        action='TICKET_DELETED',
        details='Ticket removed from system',
    )

    db.session.delete(ticket)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Ticket deleted successfully'}), 200


@app.route('/api/research/analysis', methods=['GET'])
def research_analysis_metrics():
    """
    Research endpoint providing academic-grade analysis metrics.
    
    Returns aggregated statistics on:
    - Priority distribution and decision patterns
    - Category risk profiles
    - Resolution time predictions
    - System decision confidence calibration
    """
    tickets = Ticket.query.all()
    complaints = Complaint.query.all()
    
    if not tickets:
        return jsonify({
            'status': 'success',
            'message': 'No tickets for analysis',
            'summary': {}
        }), 200
    
    # Priority distribution
    priority_dist = {}
    for ticket in tickets:
        priority = ticket.priority
        priority_dist[priority] = priority_dist.get(priority, 0) + 1
    
    # Category analysis
    category_dist = {}
    for ticket in tickets:
        category = ticket.category
        category_dist[category] = category_dist.get(category, 0) + 1
    
    # Complexity analysis
    avg_complexity = sum(ticket.complexity_score or 0 for ticket in tickets) / max(1, len(tickets))
    
    # Sentiment distribution
    sentiment_dist = {}
    for ticket in tickets:
        sentiment = ticket.sentiment or 'Neutral'
        sentiment_dist[sentiment] = sentiment_dist.get(sentiment, 0) + 1
    
    # Resolution metrics from complaints
    closed_complaints = [c for c in complaints if c.status == 'Closed']
    avg_resolution_hours = (
        sum(c.resolution_time_hours or 0 for c in closed_complaints) / max(1, len(closed_complaints))
        if closed_complaints else 0
    )
    
    avg_satisfaction = (
        sum(c.customer_satisfaction_score or 0 for c in complaints) / max(1, len(complaints))
        if complaints else 0
    )
    
    return jsonify({
        'status': 'success',
        'summary': {
            'total_tickets': len(tickets),
            'total_complaints': len(complaints),
            'avg_complexity': round(avg_complexity, 2),
            'avg_resolution_hours': round(avg_resolution_hours, 1),
            'avg_customer_satisfaction': round(avg_satisfaction, 2),
        },
        'distributions': {
            'by_priority': priority_dist,
            'by_category': category_dist,
            'by_sentiment': sentiment_dist,
        },
        'research_insights': {
            'message': 'Use this data for academic research on support ticket triage and decision-making.',
            'fields_available': [
                'complexity_score', 'sentiment', 'resolution_confidence',
                'root_cause_category', 'impact_level', 'recurrence_count',
                'resolution_time_hours', 'customer_satisfaction_score'
            ]
        }
    }), 200


@app.route('/static/<filename>')
def serve_static(filename):
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    return send_from_directory(static_dir, filename)


@app.route('/model', methods=['GET'])
def view_model_page():
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Support Model Dashboard</title>
        <style>
            :root {
                --bg: #f4f7fb;
                --panel: #ffffff;
                --panel-soft: #f8fbff;
                --primary: #1d4ed8;
                --primary-dark: #1e3a8a;
                --success: #166534;
                --warning: #b45309;
                --danger: #b91c1c;
                --text: #10213a;
                --muted: #5b6b84;
                --line: #dfe8f3;
                --shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            }

            * { box-sizing: border-box; }
            body {
                margin: 0;
                font-family: "Segoe UI", Arial, sans-serif;
                background: linear-gradient(180deg, #eef4ff 0%, var(--bg) 100%);
                color: var(--text);
            }
            .page-shell {
                max-width: 1180px;
                margin: 32px auto;
                padding: 24px;
            }
            .topbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 24px;
                gap: 16px;
            }
            .brand {
                font-size: 12px;
                letter-spacing: 0.12em;
                text-transform: uppercase;
                color: var(--primary);
                font-weight: 700;
            }
            .nav-link {
                display: inline-flex;
                align-items: center;
                padding: 10px 16px;
                background: #e0ebff;
                color: var(--primary-dark);
                border-radius: 10px;
                text-decoration: none;
                font-weight: 700;
                border: 1px solid #c7d9ff;
            }

            .content-grid {
                display: grid;
                grid-template-columns: 1.1fr 0.9fr;
                gap: 24px;
            }

            .panel {
                background: var(--panel);
                border: 1px solid var(--line);
                border-radius: 18px;
                box-shadow: var(--shadow);
            }

            .form-panel {
                padding: 28px;
            }
            .form-panel h1 {
                margin: 0 0 6px;
                font-size: 2rem;
            }
            .subtitle {
                margin: 0 0 22px;
                color: var(--muted);
                line-height: 1.6;
            }
            form {
                display: grid;
                grid-template-columns: repeat(2, minmax(180px, 1fr));
                gap: 18px;
            }
            .field {
                display: grid;
                gap: 8px;
            }
            .field.full {
                grid-column: 1 / -1;
            }
            label {
                font-size: 0.82rem;
                font-weight: 700;
                color: var(--muted);
                letter-spacing: 0.02em;
            }
            input, select, textarea {
                width: 100%;
                border: 1px solid #ccd9ef;
                border-radius: 10px;
                background: var(--panel-soft);
                padding: 12px 14px;
                font-size: 0.96rem;
                color: var(--text);
                transition: border-color 0.2s ease, box-shadow 0.2s ease;
            }
            input:focus, select:focus, textarea:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.12);
            }
            textarea {
                min-height: 146px;
                resize: vertical;
            }
            .primary-button {
                grid-column: 1 / -1;
                border: none;
                border-radius: 12px;
                background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
                color: white;
                padding: 14px 18px;
                font-size: 1rem;
                font-weight: 700;
                cursor: pointer;
                transition: transform 0.15s ease, box-shadow 0.2s ease;
                box-shadow: 0 10px 20px rgba(29, 78, 216, 0.18);
            }
            .primary-button:hover {
                transform: translateY(-1px);
            }

            .result-panel {
                padding: 24px 22px;
                display: flex;
                flex-direction: column;
                gap: 18px;
                background: linear-gradient(180deg, #f8fbff 0%, #ffffff 100%);
            }
            .status-badge {
                align-self: flex-start;
                padding: 8px 12px;
                border-radius: 999px;
                background: #e7f5ed;
                color: var(--success);
                border: 1px solid #bae9c9;
                font-size: 0.78rem;
                font-weight: 700;
                letter-spacing: 0.04em;
                text-transform: uppercase;
            }
            .result-title {
                font-size: 1.3rem;
                margin: 0;
            }
            .metrics {
                display: grid;
                grid-template-columns: repeat(2, minmax(110px, 1fr));
                gap: 12px;
            }
            .metric {
                background: var(--panel-soft);
                border: 1px solid var(--line);
                border-radius: 12px;
                padding: 12px 14px;
            }
            .metric-label {
                display: block;
                color: var(--muted);
                font-size: 0.72rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                margin-bottom: 6px;
            }
            .metric-value {
                font-size: 1.2rem;
                font-weight: 800;
                color: var(--text);
            }
            .priority-pill {
                display: inline-flex;
                align-items: center;
                border-radius: 999px;
                padding: 6px 10px;
                background: #dbeafe;
                color: var(--primary-dark);
                font-weight: 800;
            }
            .action-box {
                background: #f0f9ff;
                border: 1px solid #cfe8ff;
                border-radius: 12px;
                padding: 16px;
                color: var(--text);
                line-height: 1.6;
            }
            .error-box {
                display: none;
                margin-top: 18px;
                background: #fef2f2;
                border: 1px solid #fecaca;
                color: var(--danger);
                border-radius: 12px;
                padding: 12px 14px;
                font-weight: 600;
            }
            .error-box.visible { display: block; }
            .hidden { display: none; }

            @media (max-width: 860px) {
                .content-grid { grid-template-columns: 1fr; }
                form { grid-template-columns: 1fr; }
                .topbar { flex-direction: column; align-items: flex-start; }
            }
        </style>
    </head>
    <body>
        <div class="page-shell">
            <div class="topbar">
                <div>
                    <div class="brand">Support Intelligence</div>
                </div>
                <a class="nav-link" href="/dashboard">← Return to Dashboard</a>
            </div>

            <div class="content-grid">
                <div class="panel form-panel">
                    <h1>Support Model</h1>
                    <p class="subtitle">Capture the customer issue, assess its urgency, and receive an AI-assisted routing recommendation.</p>

                    <form id="analyze-ticket-form">
                        <div class="field">
                            <label for="email">Email</label>
                            <input id="email" name="email" type="email" required>
                        </div>
                        <div class="field">
                            <label for="category">Category</label>
                            <select id="category" name="category">
                                <option value="Billing">Billing</option>
                                <option value="Technical">Technical</option>
                                <option value="Authentication">Authentication</option>
                                <option value="General">General</option>
                            </select>
                        </div>
                        <div class="field full">
                            <label for="subject">Subject</label>
                            <input id="subject" name="subject" type="text" required>
                        </div>
                        <div class="field">
                            <label for="priority">Priority</label>
                            <select id="priority" name="priority">
                                <option value="Low">Low</option>
                                <option value="Medium" selected>Medium</option>
                                <option value="High">High</option>
                                <option value="Urgent">Urgent</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="Open">Open</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Resolved">Resolved</option>
                                <option value="Closed">Closed</option>
                            </select>
                        </div>
                        <div class="field full">
                            <label for="description">Description</label>
                            <textarea id="description" name="description" required></textarea>
                        </div>
                        <button type="submit" class="primary-button">Submit Ticket</button>
                    </form>

                    <div id="error-box" class="error-box"></div>
                </div>

                <aside class="panel result-panel" id="result-panel">
                    <span class="status-badge">Awaiting analysis</span>
                    <h2 class="result-title">Prediction Summary</h2>
                    <div class="metrics">
                        <div class="metric">
                            <span class="metric-label">Priority</span>
                            <span class="metric-value priority-pill" id="predicted-priority">Pending</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Risk score</span>
                            <span class="metric-value" id="risk-score">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Confidence</span>
                            <span class="metric-value" id="confidence">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Category</span>
                            <span class="metric-value" id="category-summary">--</span>
                        </div>
                    </div>
                    <div class="action-box">
                        <strong>Recommended action:</strong><br>
                        <span id="recommended-action">The model will suggest the best next step after the ticket is analyzed.</span>
                    </div>
                    <div class="action-box">
                        <strong>Estimated resolution:</strong><br>
                        <span id="resolution-hours">--</span>
                    </div>
                </aside>
            </div>
        </div>

        <script>
            document.getElementById('analyze-ticket-form').addEventListener('submit', async function (event) {{
                event.preventDefault();
                const form = event.target;
                const payload = {{
                    email: form.email.value,
                    category: form.category.value,
                    subject: form.subject.value,
                    priority: form.priority.value,
                    status: form.status.value,
                    description: form.description.value,
                }};

                const response = await fetch('/api/model/analyze', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(payload)
                }});
                const result = await response.json();
                const errorBox = document.getElementById('error-box');
                const badge = document.querySelector('.status-badge');

                if (!response.ok) {{
                    errorBox.textContent = result.message || 'Model analysis failed.';
                    errorBox.classList.add('visible');
                    badge.textContent = 'Analysis failed';
                    return;
                }}

                errorBox.classList.remove('visible');
                const prediction = result.prediction || {{}};
                document.getElementById('predicted-priority').textContent = prediction.predicted_priority || 'Unknown';
                document.getElementById('risk-score').textContent = (prediction.risk_score ?? 0) + '/100';
                document.getElementById('confidence').textContent = prediction.confidence || 'Medium';
                document.getElementById('category-summary').textContent = prediction.category || 'General';
                document.getElementById('recommended-action').textContent = prediction.recommended_action || 'No recommendation available.';
                document.getElementById('resolution-hours').textContent = prediction.estimated_resolution_hours ? (prediction.estimated_resolution_hours + ' hours') : '--';
                badge.textContent = 'Analysis complete';
            }});
        </script>
    </body>
    </html>
    """
    return Response(html_content, mimetype='text/html')


@app.route('/dashboard', methods=['GET'])
def view_dashboard():
    seed_complaint_data()
    tickets = [ticket.to_dict() for ticket in Ticket.query.order_by(Ticket.created_at.desc()).all()]
    complaints = [complaint.to_dict() for complaint in Complaint.query.order_by(Complaint.created_at.desc()).all()]
    chart_filename = generate_ticket_charts(tickets)

    complaint_cards = "".join(
        f"""
        <div class=\"complaint-card\">
            <div class=\"complaint-title\">{item['title']}</div>
            <div class=\"complaint-meta\"><strong>Case:</strong> {item['id']} | <strong>Customer:</strong> {item['customer_name']} | <strong>Status:</strong> {item['status']}</div>
            <p>{item['description']}</p>
            <div class=\"resolution\"><strong>Employee:</strong> {item.get('employee_name') or 'Unassigned'}<br><strong>Solution:</strong> {item.get('resolution_summary') or item.get('solution_summary') or 'Pending investigation'}</div>
        </div>
        """ for item in complaints[:3]
    )

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Business Analytics Dashboard</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 0; background: #f3f6fb; color: #1f2937; }}
            .container {{ max-width: 1200px; margin: 32px auto; padding: 24px; background: #ffffff; border-radius: 12px; box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08); }}
            .header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }}
            .kpis {{ display: grid; grid-template-columns: repeat(3, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }}
            .kpi {{ background: #eef4ff; border-radius: 10px; padding: 18px; border: 1px solid #dfe7ff; }}
            .kpi .label {{ font-size: 13px; color: #475569; text-transform: uppercase; letter-spacing: 0.05em; }}
            .kpi .value {{ font-size: 30px; font-weight: bold; margin-top: 8px; color: #0f172a; }}
            .chart-card {{ margin-top: 18px; background: #fff; border-radius: 10px; border: 1px solid #e5e7eb; padding: 14px; }}
            .complaints {{ margin-top: 26px; display: grid; gap: 16px; }}
            .complaint-card {{ background: #f8fafc; border: 1px solid #dfe7ef; border-radius: 10px; padding: 16px; }}
            .complaint-title {{ font-weight: bold; font-size: 18px; margin-bottom: 8px; }}
            .complaint-meta {{ color: #475569; font-size: 13px; margin-bottom: 8px; }}
            .resolution {{ background: #eefaf2; border: 1px solid #cde9d3; border-radius: 8px; padding: 10px; margin-top: 10px; color: #1f2937; }}
            img {{ max-width: 100%; border-radius: 8px; border: 1px solid #dbe3f0; display: block; margin: 0 auto; }}
            form {{ margin-top: 28px; display: grid; grid-template-columns: repeat(2, minmax(200px, 1fr)); gap: 14px; }}
            input, select, textarea {{ width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; box-sizing: border-box; }}
            textarea {{ min-height: 110px; resize: vertical; }}
            .full-width {{ grid-column: 1 / -1; }}
            button {{ padding: 12px 18px; background: #2563eb; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }}
            @media (max-width: 800px) {{ form {{ grid-template-columns: 1fr; }} .kpis {{ grid-template-columns: 1fr; }} }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div>
                    <h1>Customer Support Dashboard</h1>
                    <p>Business analytics for support operations and ticket intake</p>
                </div>
                <div>
                    <a href="/model" style="display:inline-block;padding:10px 16px;background:#dbeafe;color:#1e3a8a;border-radius:8px;text-decoration:none;font-weight:700;">Model Interaction</a>
                </div>
            </div>

            <div class="kpis">
                <div class="kpi">
                    <div class="label">Total Tickets</div>
                    <div class="value">{sum(1 for _ in tickets)}</div>
                </div>
                <div class="kpi">
                    <div class="label">Open Tickets</div>
                    <div class="value">{sum(1 for ticket in tickets if ticket.get('status') == 'Open')}</div>
                </div>
                <div class="kpi">
                    <div class="label">Resolved Tickets</div>
                    <div class="value">{sum(1 for ticket in tickets if ticket.get('status') == 'Resolved')}</div>
                </div>
            </div>

            <div class="chart-card">
                <img src="/static/{chart_filename}" alt="Ticket Analytics Chart">
            </div>

            <div class="complaints">
                <h2>Customer Complaint Forum</h2>
                {complaint_cards}
            </div>

            <form id="ticket-form" action="/api/tickets" method="post">
                <div>
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div>
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="Billing">Billing</option>
                        <option value="Technical">Technical</option>
                        <option value="Authentication">Authentication</option>
                        <option value="General">General</option>
                    </select>
                </div>
                <div class="full-width">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" required>
                </div>
                <div class="full-width">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                <div>
                    <label for="priority">Priority</label>
                    <select id="priority" name="priority">
                        <option value="Low">Low</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                    </select>
                </div>
                <div>
                    <label for="attachment_name">Attachment</label>
                    <input type="text" id="attachment_name" name="attachment_name" placeholder="report.pdf">
                </div>
                <div class="full-width">
                    <button type="submit">Submit Ticket</button>
                </div>
            </form>
        </div>

        <script>
            document.getElementById('ticket-form').addEventListener('submit', async function (event) {{
                event.preventDefault();
                const form = event.target;
                const payload = {{
                    email: form.email.value,
                    category: form.category.value,
                    subject: form.subject.value,
                    description: form.description.value,
                    priority: form.priority.value,
                    attachment_name: form.attachment_name.value || null,
                    user_id: 'dashboard-user'
                }};
                const response = await fetch('/api/tickets', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(payload)
                }});
                const result = await response.json();
                if (response.ok) {{
                    alert('Ticket submitted successfully.');
                    form.reset();
                    window.location.reload();
                }} else {{
                    alert(result.errors ? result.errors.join('\n') : result.message || 'Submission failed');
                }}
            }});
        </script>
    </body>
    </html>
    """
    return render_template_string(html_content)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)