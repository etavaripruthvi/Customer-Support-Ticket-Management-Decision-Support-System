import os
import pytest

from src.app import app, db, Ticket


@pytest.fixture
def client():
    app.config.update(
        TESTING=True,
        SQLALCHEMY_DATABASE_URI='sqlite:///:memory:',
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()


def test_valid_ticket_creation(client):
    response = client.post(
        '/api/tickets',
        json={
            'email': 'user@example.com',
            'subject': 'Login issue',
            'category': 'Auth',
            'description': 'Cannot sign in',
            'attachment_name': 'screenshot.png',
            'user_id': 'agent-01',
        },
    )

    assert response.status_code == 201
    payload = response.get_json()
    assert payload['status'] == 'success'
    assert payload['ticket']['email'] == 'user@example.com'
    assert payload['ticket']['status'] == 'Open'
    assert payload['ticket']['priority'] == 'Medium'
    assert payload['ticket']['id'].startswith('TICK-')


def test_validation_failures(client):
    invalid_email = client.post(
        '/api/tickets',
        json={
            'email': 'bad-email',
            'subject': 'Issue',
            'category': 'Billing',
            'description': 'desc',
        },
    )
    assert invalid_email.status_code == 400

    missing_subject = client.post(
        '/api/tickets',
        json={
            'email': 'user@example.com',
            'subject': '',
            'category': 'Billing',
            'description': 'desc',
        },
    )
    assert missing_subject.status_code == 400

    bad_attachment = client.post(
        '/api/tickets',
        json={
            'email': 'user@example.com',
            'subject': 'Issue',
            'category': 'Billing',
            'description': 'desc',
            'attachment_name': 'file.exe',
        },
    )
    assert bad_attachment.status_code == 400


def test_status_transition_and_audit_log(client):
    created = client.post(
        '/api/tickets',
        json={
            'email': 'user@example.com',
            'subject': 'Issue',
            'category': 'Billing',
            'description': 'Need update',
        },
    )
    ticket_id = created.get_json()['ticket']['id']

    response = client.patch(
        f'/api/tickets/{ticket_id}',
        json={'status': 'In Progress', 'priority': 'High', 'user_id': 'agent-42'},
    )

    assert response.status_code == 200
    payload = response.get_json()
    assert payload['ticket']['status'] == 'In Progress'
    assert payload['ticket']['priority'] == 'High'

    with open('logs/ticket_audit.log', 'r', encoding='utf-8') as audit_file:
        log_content = audit_file.read()
        assert 'STATUS_UPDATED' in log_content
        assert ticket_id in log_content


def test_list_and_detail_endpoints(client):
    client.post(
        '/api/tickets',
        json={
            'email': 'alice@example.com',
            'subject': 'Billing',
            'category': 'Billing',
            'description': 'Invoice issue',
        },
    )
    client.post(
        '/api/tickets',
        json={
            'email': 'bob@example.com',
            'subject': 'General',
            'category': 'Support',
            'description': 'Need help',
        },
    )

    list_response = client.get('/api/tickets?category=Billing')
    assert list_response.status_code == 200
    tickets = list_response.get_json()['tickets']
    assert len(tickets) == 1
    assert tickets[0]['category'] == 'Billing'

    details_response = client.get('/api/tickets/INVALID')
    assert details_response.status_code == 404


def test_delete_ticket(client):
    created = client.post(
        '/api/tickets',
        json={
            'email': 'del@example.com',
            'subject': 'Delete me',
            'category': 'Tech',
            'description': 'Remove this',
        },
    )
    ticket_id = created.get_json()['ticket']['id']

    response = client.delete(f'/api/tickets/{ticket_id}', json={'user_id': 'admin'})
    assert response.status_code == 200
    payload = response.get_json()
    assert payload['status'] == 'success'
    assert payload['message'] == 'Ticket deleted successfully'

    fetch_response = client.get(f'/api/tickets/{ticket_id}')
    assert fetch_response.status_code == 404


def test_list_all_tickets_and_missing_delete(client):
    client.post(
        '/api/tickets',
        json={
            'email': 'alpha@example.com',
            'subject': 'Alpha issue',
            'category': 'Billing',
            'description': 'Alpha desc',
        },
    )
    client.post(
        '/api/tickets',
        json={
            'email': 'beta@example.com',
            'subject': 'Beta issue',
            'category': 'Support',
            'description': 'Beta desc',
        },
    )

    all_response = client.get('/api/tickets')
    assert all_response.status_code == 200
    all_payload = all_response.get_json()
    assert all_payload['count'] == 2
    assert len(all_payload['tickets']) == 2

    missing_delete = client.delete('/api/tickets/DOES-NOT-EXIST', json={'user_id': 'ops'})
    assert missing_delete.status_code == 404


def test_invalid_update_and_dashboard_render(client):
    created = client.post(
        '/api/tickets',
        json={
            'email': 'update@example.com',
            'subject': 'Need update',
            'category': 'Billing',
            'description': 'Fix me',
        },
    )
    ticket_id = created.get_json()['ticket']['id']

    invalid_update = client.patch(
        f'/api/tickets/{ticket_id}',
        json={'status': 'Not Allowed', 'priority': 'Ultra'},
    )
    assert invalid_update.status_code == 400

    valid_update = client.patch(
        f'/api/tickets/{ticket_id}',
        json={'status': 'Resolved', 'priority': 'Urgent', 'user_id': 'agent-99'},
    )
    assert valid_update.status_code == 200
    updated = valid_update.get_json()['ticket']
    assert updated['status'] == 'Resolved'
    assert updated['priority'] == 'Urgent'

    dashboard_response = client.get('/dashboard')
    assert dashboard_response.status_code == 200
    body = dashboard_response.get_data(as_text=True)
    assert 'Customer Support Dashboard' in body
    assert 'ticket_status_chart.png' in body


def test_model_analysis_endpoint_and_frontend_route(client):
    response = client.post(
        '/api/model/analyze',
        json={
            'email': 'user@example.com',
            'subject': 'Charged twice for subscription',
            'category': 'Billing',
            'description': 'I was charged twice and cannot access my account after a refund request.',
            'priority': 'Medium',
        },
    )

    assert response.status_code == 200
    payload = response.get_json()
    assert payload['status'] == 'success'
    prediction = payload.get('prediction') or payload.get('analysis') or {}
    assert prediction.get('predicted_priority') in {'Low', 'Medium', 'High', 'Urgent'}
    assert prediction.get('recommended_action')

    page_response = client.get('/model')
    assert page_response.status_code == 200
    page_html = page_response.get_data(as_text=True)
    assert 'Support Model' in page_html
    assert 'analyze-ticket-form' in page_html
    assert 'Submit Ticket' in page_html


def test_customer_complaint_workflow_seed_data(client):
    complaints_response = client.get('/api/complaints')
    assert complaints_response.status_code == 200
    complaints = complaints_response.get_json()['complaints']
    assert complaints
    assert any(item.get('status') == 'Closed' for item in complaints)
    assert any(item.get('employee_name') for item in complaints)
    assert any(item.get('resolution_summary') for item in complaints)
