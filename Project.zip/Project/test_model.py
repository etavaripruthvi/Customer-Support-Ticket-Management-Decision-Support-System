import sys
sys.path.insert(0, 'e:\\Customer-Support-Ticket-Management-System-main')

from src.app import analyze_ticket_with_model
import json

data = {
    'subject': 'Critical API outage affecting all users',
    'description': 'API completely down for 30 minutes. Customers cannot access any services.',
    'category': 'Technical',
    'priority': 'Urgent'
}

result = analyze_ticket_with_model(data)
print(json.dumps(result, indent=2))
